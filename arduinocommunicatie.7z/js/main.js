//DOM ready
$(init);

/**
 * Initialize application
 */
function init()
{
	console.log("jQuery enabled");
}

function btnClick(btnID)
{
	//console.log(document.getElementById('club-name').value);
	if(btnID != 0) { // zoeken op
	
		$.getJSON("./php/main.php?dir="+btnID).done(jsonLoaded);	
		console.log(btnID)
	}
}

function jsonLoaded(data)
{
	console.log("json is geladen");
	var location = document.getElementById("pressed");
	
	location.innerHTML = "";
	
	for( var i = 0; i < data.length; i++)
	{
  		console.log(data[i]);
  		location.innerHTML = data[i];
	}
	console.log(data);
}