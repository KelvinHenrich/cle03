<?php
//Database
mysqli_report(MYSQLI_REPORT_STRICT); // Make sure we can catch errors
define("DB_HOST", "localhost");
define("DB_USER", "root");
define("DB_PASS", "");
define("DB_DATABASE", "cmgtcle03");

//Flickr
define("FLICKR_KEY", "f3264ac8c5cfa5f23707f8527a8ec310");
define("FLICKR_SECRET", "f9c73779632a1d52");