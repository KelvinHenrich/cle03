<?php
$dir = isset($_GET['dir']) ? $_GET['dir'] : null;

if (!empty($dir)) {

	$file = fopen("../direction.txt", "w") or die("Unable to open file!");

	fwrite($file, $dir);

	header('Content-type: application/json');
	echo json_encode($dir);
}
exit;