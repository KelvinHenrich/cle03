//dropdown menu
//Ignore any errors in this section its fully working,
document.getElementById("nav01").innerHTML =
    "<div class='dropdown'>" +
    "<button class='dropbtn'> Dropdown </button>" +
    // "<img src='https://cdn2.iconfinder.com/data/icons/flat-icons-web/40/Menu-128.png' alt='Smiley face' height='24' width='24'>" +

    "<div class='dropdown-content'>" +
    "<a href='index.html'>Home</a>" +
    "<a href='directlocation.html'>Directe locatie</a>" +
    "<a href='bluetooth.html'>Weersverwachting</a>" +
    "<a href='compass.html'>Control the compass</a>" +
    "</div>" +
    "</div>";
//you may now look at errors again.

window.addEventListener('load', init);

//Global vars

/**
 * Execute after DOM ready
 */

function init()
{
    getAllLocations();
}


function getAllLocations (){
    //get the dish information from the server
    //AJAX request
    // writeToTheDOM
    //
    makeAjaxRequest();
}

function makeAjaxRequest () {
    $.ajax({
        url: '../server/index.php',
        dataType: 'json',
        // data: location,
        success : succesLocationHandler
    });
}

function makeAjaxDetails () {
    $.ajax({
        url: '../server/index.php',
        dataType: 'json',
        data: location,
        success : succesLocationHandler
    });
}

function succesLocationHandler (data) {
    console.log(data.locations[1].id);
    //

    for (var i = 0 ; i < data.locations.length; i++){
        //writeToTheDOM('h2',data.dishes[i].name);
        //writeToTheDOM('img', data.dishes[i].name , 'src');
        writeToTheDOM({
            'tag' : 'img',
            //'content'  : data.dishes[i].name,
            'attributes' : {
                'src' : data.locations[i].images[0],
                'class': 'image'
            }
        });
    }

    //{
    //   tag: 'tagname',
    //   content : 'content',
    //   attributes :  {
    //   'src' : 'src_name',
    //   'className' : className,
    //   'id'  : 'id'
    //}
    //}
}

function writeToTheDOM (element) {
    // <h2 class='h2_heading'>Heading_text</h2>
    // <img src='link_to_image'>
    // <p>paragraph_text</p>

    //where to place it into the dom
    var placeHolder = document.getElementById('location-gallery');

    //create html
    var tag = document.createElement(element.tag);
    if(element.content) {
        tag.innerHTML = element.content;
    }
    //tag.innerHTML = element;
    if(element.attributes) {
        tag.setAttribute('src', element.attributes.src);
    }
    //Append
    //console.log(element);
    placeHolder.appendChild(tag);
}

function btnClick(btnID)
{
    //console.log(document.getElementById('club-name').value);
    if(btnID != 0) { // searching on

        $.getJSON("../server/main.php?dir="+btnID).done(jsonLoaded);
        // console.log(btnID)
    }
}

function jsonLoaded(data)
{
    // console.log("json is geladen");
    var location = document.getElementById("pressed");

    location.innerHTML = "";

    for( var i = 0; i < data.length; i++)
    {
        // console.log(data[i]);
        location.innerHTML = data[i];
    }
    // console.log(data);
}